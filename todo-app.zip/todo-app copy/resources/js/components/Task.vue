<template>
    <div class="container mt-4">
        <h1 class="text-center">Task Manager</h1>
        <form @submit.prevent="createTask" class="mb-4">
            <div class="mb-3">
                <label class="form-label">Task Name</label>
                <input v-model="task.name" class="form-control" type="text" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Start Date</label>
                <input v-model="task.start_date" class="form-control" type="date" required />
            </div>
            <div class="mb-3">
                <label class="form-label">End Date</label>
                <input v-model="task.end_date" class="form-control" type="date" required />
            </div>
            <div class="mb-3">
                <label class="form-label">Resource Name</label>
                <input v-model="task.resource_name" class="form-control" type="text" required />
            </div>
            <button class="btn btn-primary" type="submit">Add Task</button>
        </form>
    </div>

    <div class="container mt-4">
        <h2 class="text-center mb-4">Task Table</h2>

        <div class="row mb-3">
            <div class="col-md-4">
                <label for="filter_start_date" class="form-label">Filter Start Date</label>
                <input
                    v-model="filter.start_date"
                    id="filter_start_date"
                    class="form-control"
                    type="date"
                />
            </div>
            <div class="col-md-4">
                <label for="filter_end_date" class="form-label">Filter End Date</label>
                <input
                    v-model="filter.end_date"
                    id="filter_end_date"
                    class="form-control"
                    type="date"
                />
            </div>
            <div class="col-md-4 d-flex align-items-end">
                <button class="btn btn-primary w-100" @click="fetchTasks">Filter</button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col" v-for="resource in resources" :key="resource">
                            {{ resource }}
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="date in dates" :key="date" :class="{ 'table-active': isWeekend(date) }">
                        <th scope="row">{{ formatDate(date) }}</th>
                        <td v-for="resource in resources" :key="resource">
                            <span v-for="task in getTasksForDateAndResource(date, resource)" :key="task.id">
                              {{ task.name }}<b v-if="count(getTasksForDateAndResource(date, resource)) > 1">, </b>
                            </span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    import axios from 'axios';
    import dayjs from 'dayjs';
    import weekday from 'dayjs/plugin/weekday';

    export default {
        data() {
            return {
                task: {
                    name: '',
                    start_date: '',
                    end_date: '',
                    resource_name: '',
                },
                tasks: [],
                filter: {
                    start_date: '',
                    end_date: '',
                },
            };
        },
        computed: {
            dates() {
                const dates = this.tasks.map((task) => task.start_date);
                return [...new Set(dates)].sort();
            },
            resources() {
                const resources = this.tasks.map((task) => task.resource_name);
                return [...new Set(resources)];
            },
        },
        methods: {
            async createTask() {
                try {
                    await axios.post('/api/tasks', this.task);
                    alert('Task created!');
                    this.$emit('taskCreated');
                    await this.fetchTasks();
                    this.task = {
                        name: '',
                        start_date: '',
                        end_date: '',
                        resource_name: '',
                    };
                } catch (error) {
                    console.error(error);
                }
            },
            formatDate(date) {
                return new Date(date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
            },
            async fetchTasks() {
                try {
                    const response = await axios.get('/api/tasks', { params: this.filter });
                    this.tasks = response.data.tasks;
                } catch (error) {
                    console.error('Error fetching tasks:', error);
                }
            },
            getTasksForDateAndResource(date, resource) {
                return this.tasks.filter(
                    (task) => task.start_date === date && task.resource_name === resource
                );
            },
            count(data) {
                return data.length;
            },
            isWeekend(date) {
                const day = dayjs(date, 'DD MMM').day();
                return day === 0 || day === 6;
            },
        },
        mounted() {
            dayjs.extend(weekday);
            this.filter.start_date = dayjs().weekday(0).format('YYYY-MM-DD');
            this.filter.end_date = dayjs().weekday(0).add(2, 'week').endOf('week').format('YYYY-MM-DD');
            this.fetchTasks();
        },

    };
</script>
<style>
    .weekend {
        background-color: lightgray;
    }
</style>
