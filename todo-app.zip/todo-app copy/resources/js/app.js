import { createApp } from 'vue';
import Task from './components/Task.vue';

import 'bootstrap/dist/css/bootstrap.css';

const app = createApp(Task);
app.mount('#app');
