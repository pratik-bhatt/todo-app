<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index(Request $request)
    {
        $resources = Task::select('resource_name')->distinct()->get();
        $startDate = $request->get('start_date');
        $endDate = $request->get('end_date');

        if (!isset($startDate) && !isset($endDate)) {
            $startDate = date('Y-m-d');
            $endDate = date('Y-m-d', strtotime($startDate . ' + 2 weeks'));
        }

        $tasks = Task::whereBetween('start_date', [$startDate, $endDate])->get();

        return response()->json(['tasks' => $tasks, 'resources' => $resources]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string',
            'start_date' => 'required|date',
            'end_date' => 'required|date',
            'resource_name' => 'required|string',
        ]);

        Task::create($validated);
        return response()->json(['message' => 'Task created successfully']);
    }
}
